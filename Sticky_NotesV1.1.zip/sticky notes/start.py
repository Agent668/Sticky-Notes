import pygame
import subprocess
import os
import sys
import time

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Sticky Notes")
clock = pygame.time.Clock()
running = True
light_gray = (137, 137, 137)
dark_gray = (83, 83, 83)
text_color = (0, 0, 0)

font1 = pygame.font.Font(None, 64)
font2 = pygame.font.Font(None, 30)
font3 = pygame.font.Font(None, 30)

over_left = False
over_right = False

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MAIN_PATH = os.path.join(SCRIPT_DIR, "main.py")
MODE_PATH = os.path.join(SCRIPT_DIR, "mode.txt")
image_path = os.path.join(SCRIPT_DIR, "note.png")
note_image = pygame.image.load(image_path)
pygame.display.set_icon(note_image)

def set_mode_and_launch(mode):
    with open(MODE_PATH, "w") as f:
        f.write(str(mode))
    pygame.quit()
    time.sleep(1)
    subprocess.run([sys.executable, MAIN_PATH])

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if over_left:
                set_mode_and_launch(0)
                running = False
            elif over_right:
                set_mode_and_launch(1)
                running = False

    screen.fill(light_gray)
    title_text = font1.render("STICKY NOTES", True, text_color)
    screen.blit(title_text, title_text.get_rect(center=(400, 150)))

    mouse = pygame.mouse.get_pos()
    pygame.draw.rect(screen, text_color, pygame.Rect(100, 400, 250, 100), 3)
    pygame.draw.rect(screen, dark_gray, pygame.Rect(450, 400, 250, 100))
    pygame.draw.rect(screen, text_color, pygame.Rect(450, 400, 250, 100), 3)

    screen.blit(font2.render("Launch Light Gray Mode", True, text_color), (105, 440))
    screen.blit(font3.render("Launch Dark Gray Mode", True, (255, 255, 255)), (457, 440))

    over_left = (100 < mouse[0] < 350) and (400 < mouse[1] < 500)
    over_right = (450 < mouse[0] < 700) and (400 < mouse[1] < 500)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
