import pygame
import os

pygame.init()
screen = pygame.display.set_mode((300, 300))
pygame.display.set_caption("Sticky Note")
script_dir = os.path.dirname(__file__)
image_path = os.path.join(script_dir, "note.png")
note_image = pygame.image.load(image_path)
pygame.display.set_icon(note_image)
clock = pygame.time.Clock()
running = True
black = (0, 0, 0)
white = (255, 255, 255)
size = 32
font = pygame.font.Font(None, size)
light_gray = (137, 137, 137)
dark_gray = (83, 83, 83)
text_color = black
color_mode = light_gray
mode = 0
mode_path = os.path.join(script_dir, "mode.txt")
try:
    with open(mode_path, "r") as f:
        mode = int(f.read().strip())
except:
    print("Mode file missing or invalid. Defaulting to light mode.")

color_mode = (137, 137, 137)
text_color = (0, 0, 0)
if mode == 1:
    color_mode = (83, 83, 83)
    text_color = (255, 255, 255)
frame = 0

text = {}
text[0] = []
busy = 0
render_this = {}
load_text = {}
text_rect = {}
top_left = {}
top_left[0] = [0, 0]
new_line = False
line_total = 0

line = 0
line_lenght = 0 #max 24

upper_case = False
x = "a"

def printaj():
    global text
    global render_this
    global load_text
    global text_rect
    global top_left
    global line_total
    global text_color
    global screen
    global line
    for i in range(line+1):
        render_this[line -i] = "".join(text[line-i]) #joinan text
        load_text[line-i] = font.render(render_this[line-i], True, text_color) # text v obliki fonta
        text_rect[line-i] = load_text[line-i].get_rect() #ploščina texta
        text_rect[line-i].topleft = top_left[line-i] #zacetna pozicija texta
        screen.blit(load_text[line-i], text_rect[line-i]) #narisi text

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == (pygame.K_LSHIFT or pygame.K_RSHIFT):
                if not upper_case:
                    upper_case = True
                else:
                    upper_case = False
            if busy == 0:
                if event.key == pygame.K_RETURN:
                    if line < line_total:
                        line += 1
                    elif line == line_total:
                        new_line = True
                elif event.key == pygame.K_BACKSPACE:
                    if line_lenght == 0 and line > 0:
                        line -= 1
                        if len(text[line]) > 0:
                            text[line].pop(len(text[line])-1)
                    elif line_lenght > 0:
                        text[line].pop(len(text[line])-1)
                elif event.key == pygame.K_SPACE:
                    text[line].append(" ")
                else:
                    if event.key != pygame.K_BACKSPACE and event.key != (pygame.K_LSHIFT or pygame.K_RSHIFT):
                        if not upper_case:
                            text[line].append(pygame.key.name(event.key))
                        else:
                            text[line].append(pygame.key.name(event.key).capitalize())

                busy = 1
        if event.type == pygame.KEYUP:
            busy = 0
    screen.fill(color_mode)
    line_lenght = len(text[line])
    if line > line_total:
        line_total = line
    if (line_lenght == 24 or new_line) and (line+1 > line_total):
        line += 1
        text[line] = []
        render_this[line] = ""
        load_text[line] = ""
        top_left[line] = [0, top_left[line-1][1] + 20]
        new_line = False
    
    cursor_x_offset = font.size("".join(text[line]))[0]
    cursor_y_offset = top_left[line][1]
    frame += 1
    if (frame//30)%2==0:
        pygame.draw.line(screen, text_color,
                 (cursor_x_offset, cursor_y_offset),
                 (cursor_x_offset, cursor_y_offset + font.get_height()), 2)
    


    printaj()
    



    pygame.display.flip()

    clock.tick(60)

pygame.quit()
